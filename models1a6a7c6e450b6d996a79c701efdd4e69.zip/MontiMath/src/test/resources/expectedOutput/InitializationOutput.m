package expectedOutput;


script InitializationOutput
	Q A = 1/1;
	Q B = 2/1;
	Q^{2,2} C = [1/1,1/1;1/1,1/1];
	Q^{2,2} D = [1/1,2/1;3/1,4/1];
end
