package expectedOutput;


script UnitsOutput
	Q A = 5/1m;
	Q B = 1/1m;
	Q^{1,2} C = [1/1m,2/1m];
	Q F = 2/1m*s;
	Q D = 1/1m^2;
	Q E = 441/1m^4;
end
