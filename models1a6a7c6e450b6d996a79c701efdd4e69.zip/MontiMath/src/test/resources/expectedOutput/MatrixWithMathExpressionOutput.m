package expectedOutput;


script MatrixWithMathExpressionOutput
	Q B = 5/1;
	Q C = 3/1;
	Q^{2,2} A = [2/1,32/5;-32/5,-94/25];
	Q^{3,2} D = [2/1,8/1;4/1,10/1;6/1,12/1];
end
