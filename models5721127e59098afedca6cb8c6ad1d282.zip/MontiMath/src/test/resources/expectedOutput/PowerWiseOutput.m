package expectedOutput;


script PowerWiseOutput
	Q^{1,2} A = [1/1,4/1];
	Q^{1,2} Bmat = [49/1,100/1];
end
