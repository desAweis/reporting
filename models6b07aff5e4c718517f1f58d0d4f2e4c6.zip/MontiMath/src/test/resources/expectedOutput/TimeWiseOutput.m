package expectedOutput;


script TimeWiseOutput
	Q^{1,2} A = [2/1,4/1];
	Q^{1,2} Bmat = [20/1,36/1];
end
