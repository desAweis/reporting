package expectedOutput;


script Units2Output
	Q^{1,2} A = [1/1m,2/1m];
	Q^{2,1} Bmat = [1/1m;2/1m];
	Q^{1,1} Cmat = [5/1m^2];
	Q D = 2/1m;
	Q E = 5/1m;
	Q F = 13/1m^2;
end
