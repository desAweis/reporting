package expectedOutput;


script If2Output
	Q cond = 1/1;
	Q result = 1/1;
end
