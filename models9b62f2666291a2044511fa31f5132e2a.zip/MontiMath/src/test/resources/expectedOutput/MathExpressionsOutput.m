package expectedOutput;


script MathExpressionsOutput
	Q A = 3/1;
	Q Bmat = 6/1;
	Q Cmat = 441/1;
	Q^{2,2} D = [42/1,42/1;42/1,42/1];
	Q E = 4/1;
end
