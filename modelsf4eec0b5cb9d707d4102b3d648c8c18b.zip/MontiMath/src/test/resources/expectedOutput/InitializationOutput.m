package expectedOutput;


script InitializationOutput
	Q A = 1/1;
	Q Bmat = 2/1;
	Q^{2,2} Cmat = [1/1,1/1;1/1,1/1];
	Q^{2,2} D = [1/1,2/1;3/1,4/1];
end
